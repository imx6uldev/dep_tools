#pragma once

void printA(void);
void printB(void);
void printC(void);
void printD(void);
void printE(void);
